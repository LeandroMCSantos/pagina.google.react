import * as React from 'react';
import { Text, View, StyleSheet, TextInput, Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

const Avatar = () => (
  <Image
    source={{ uri: 'https://i.pinimg.com/564x/a3/ea/82/a3ea826c0a9b8f7b2df6e666e7c146f2.jpg' }}
    style={styles.avatar}
  />
);

const Dots = () => (
  <View style={styles.dotsContainer}>
    <View style={styles.dot} />
    <View style={styles.dot} />
    <View style={styles.dot} />
  </View>
);

export default function App() {
  const [searchText, setSearchText] = React.useState('');

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Dots />
        <Avatar />
      </View>
      <Image
        source={{ uri: 'https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png' }}
        style={styles.logo}
      />
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Pesquisar"
          value={searchText}
          onChangeText={text => setSearchText(text)}
        />
      </View>
      <Card>
        <AssetExample />
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginRight: 16,
  },
  dotsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#000',
    marginRight: 4,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 66,
    marginTop: 10,
  },
  logo: {
    width: 272,
    height: 92,
    resizeMode: 'contain',
    alignSelf: 'center',
    marginTop: 30,

  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 8,
    height: 40,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    paddingHorizontal: 16,
  },
});
